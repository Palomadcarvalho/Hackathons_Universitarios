package modelos;

public interface Avaliavel {
    void calcularNotaFinal();
}