package modelos;

public class Estudante extends Pessoa {
    public Estudante(String nome, Instituicao instituicao) {
        super(nome, instituicao);
    }
}