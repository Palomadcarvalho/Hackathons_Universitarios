package modelos;

public class Universidade extends Instituicao {
    public Universidade(String nome) {
        super(nome);
    }
}