package modelos;

public class Jurado extends Profissional {
    public Jurado(String nome, Instituicao instituicao) {
        super(nome, instituicao);
    }
}