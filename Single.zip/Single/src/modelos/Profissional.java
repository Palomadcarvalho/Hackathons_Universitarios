package modelos;

public class Profissional extends Pessoa {
    public Profissional(String nome, Instituicao instituicao) {
        super(nome, instituicao);
    }
}