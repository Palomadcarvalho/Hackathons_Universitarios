package modelos;

public class Empresa extends Instituicao {
    public Empresa(String nome) {
        super(nome);
    }
}